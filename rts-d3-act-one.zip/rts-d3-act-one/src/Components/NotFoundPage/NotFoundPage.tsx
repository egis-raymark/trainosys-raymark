import React from 'react'

const NotFoundPage = () => {
  return (
    <h1>NotFoundPage</h1>
  )
}

export default NotFoundPage
